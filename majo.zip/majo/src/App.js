import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import {BrowserRouter as Router,Route,Link,Switch} from 'react-router-dom';

class App extends Component {
  render() {
    const Home =()=>(
     <div>
         
       <Link to="/">SignIn</Link></div>);
  const About = () =>(<div>
     <Link to="/Register">Register</Link></div>);
    return (
      <Router>
         <Switch>
         
           <Route path="/Register" component={Home}/>
          
           <Route path="/" component={About}/>
           
         </Switch>
      </Router>
    );
  }
  
  
}
export default App;
